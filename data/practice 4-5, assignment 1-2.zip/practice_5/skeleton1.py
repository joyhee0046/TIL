import pandas as pd

# 데이터 로드
file_path = ___________
data = ___________

# 데이터셋 기본 정보 확인
print(data.info())
print(data.describe())
