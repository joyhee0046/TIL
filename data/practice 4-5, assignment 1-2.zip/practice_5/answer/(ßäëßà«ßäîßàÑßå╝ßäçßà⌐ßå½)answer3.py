import pandas as pd
import matplotlib.pyplot as plt

# 데이터 로드
file_path = '../data/eda_data.csv'
data = pd.read_csv(file_path)

# 시간에 따른 특정 변수(column_1)의 변화 시각화
plt.figure(figsize=(12, 6))
plt.plot(data['Date'], data['column_1'], marker='o')
plt.title('Time Series of column_1')
plt.xlabel('Date')
plt.ylabel('Value')

# x축 레이블 간격 조정 (예: 20개의 레이블만 표시)
plt.xticks(ticks=range(0, len(data['Date']), len(data['Date']) // 20), rotation=45)

plt.show()
