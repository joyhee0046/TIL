import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 데이터 로드
file_path = '../data/eda_data.csv'
data = pd.read_csv(file_path)

# 여러 변수 간의 관계를 페어플롯으로 시각화
sns.pairplot(data)
plt.suptitle('Pairplot of Variables', y=1.02)
plt.show()
