import pandas as pd

# 데이터 로드
file_path = ____________
data = ___________

# 데이터 기본 정보 확인
print(data.info())
print(data.describe())
