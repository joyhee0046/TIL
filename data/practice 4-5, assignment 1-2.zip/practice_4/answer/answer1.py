import pandas as pd

# 데이터 로드
file_path = '../data/preprocessing_data.csv'
data = pd.read_csv(file_path)

# 데이터 확인
print(data.head())
print(data.info())
