import pandas as pd

# 데이터 로드
file_path = '../data/preprocessing_data.csv'
data = pd.read_csv(file_path)

# 결측치 처리 및 새로운 파생 변수 생성
data['column_with_missing'] = data['column_with_missing'].fillna(data['column_with_missing'].mean())
data['new_feature'] = data['column_1'].apply(lambda x: x ** 2)  # 'column_1'을 기준으로 새로운 파생 변수 생성

# 데이터 변환 후 요약
summary = data.describe()

# 요약 통계 출력
print(summary)
