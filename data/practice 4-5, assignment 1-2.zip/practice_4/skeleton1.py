import pandas as pd

# 데이터 로드
file_path = ______________
data = ______________

# 데이터 확인
print(data.head())
print(data.info())
