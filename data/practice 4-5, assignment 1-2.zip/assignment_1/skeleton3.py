import pandas as pd

# 데이터 로드
file_path = ___________
data = __________

# 특정 조건을 만족하는 데이터 필터링
filtered_data = ____________

# 특정 열을 기준으로 그룹화하고, 그룹별 평균값 계산
grouped_mean = ____________

# 평균값을 내림차순으로 정렬하여 출력
sorted_grouped_mean = _____________
print(sorted_grouped_mean)
