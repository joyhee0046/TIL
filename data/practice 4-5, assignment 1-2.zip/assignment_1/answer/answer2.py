import pandas as pd

# 데이터 로드
file_path = '../data/group_data.csv'
data = pd.read_csv(file_path)

# 특정 조건을 만족하는 데이터 필터링
filtered_data = data.loc[(data['value'] >= 10) & (data['value'] <= 20)]

# 특정 열을 기준으로 그룹화하고 요약 통계 계산 (예: 'category' 열 기준)
grouped_data = filtered_data.groupby('category').describe()

# 그룹별 요약 통계 확인
print(grouped_data)
