import pandas as pd

# 데이터 로드
file_path = '../data/group_data.csv'
data = pd.read_csv(file_path)

# 특정 조건을 만족하는 데이터 필터링
filtered_data = data.loc[(data['value'] >= 10) & (data['value'] <= 20)]

# 특정 열을 기준으로 그룹화하고, 그룹별 평균값 계산
grouped_mean = filtered_data.groupby('category')['value'].mean()

# 평균값을 내림차순으로 정렬하여 출력
sorted_grouped_mean = grouped_mean.sort_values(ascending=False)
print(sorted_grouped_mean)
