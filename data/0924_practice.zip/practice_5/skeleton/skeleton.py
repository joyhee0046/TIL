import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 1. 웹 드라이버 설정
def setup_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("_________")  # --no-sandbox
    options.add_argument("_________")  # --disable-dev-shm-usage
    driver = webdriver.Chrome(options=options)
    return driver

# 2. 웹페이지로 이동
def navigate_to_page(driver):
    driver.get("_________")  # 서울시 실시간 교통 정보 웹페이지 URL
    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.ID, "_________"))  # 콘텐츠가 로드될 때까지 대기
    )

# 3. 특정 구 검색 및 결과 로드
def search_keyword(driver, keyword):
    contents_area = driver.find_element(By.ID, "_________")  # 검색 영역을 찾아서
    search_box = contents_area.find_element(By.CSS_SELECTOR, "input._________")  # 검색창 찾기
    search_box.send_keys(keyword)  # 검색 키워드 입력
    search_button = contents_area.find_element(By.CSS_SELECTOR, "input._________")  # 검색 버튼 클릭
    search_button.click()
    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.CLASS_NAME, "_________"))  # 결과 대기
    )

# 4. 검색 결과 크롤링
def scrape_results(driver):
    aside_content = driver.find_element(By.CLASS_NAME, "_________")  # 결과가 있는 영역 찾기
    result_sections = {
        "도로": "_________",  # 도로 결과 ID
        "버스": "_________",  # 버스 결과 ID
        "정류소": "_________",  # 정류소 결과 ID
        "따릉이": "_________",  # 따릉이 결과 ID
        "주차장": "_________"  # 주차장 결과 ID
    }
    data = {section: [] for section in result_sections.keys()}
    for section_name, result_id in result_sections.items():
        results = aside_content.find_element(By.ID, result_id).find_elements(By.TAG_NAME, "_________")  # 항목 태그 찾기
        for result in results:
            item_text = result.text.strip().replace("_________", " | ")  # 줄바꿈 제거 및 구분자 추가
            data[section_name].append(item_text)
    return data

# 5. 데이터를 CSV로 저장
def save_data_to_csv(data):
    all_data = [(category, item) for category, items in data.items() for item in items if item != "_________"]  # "검색된 내역이 없습니다." 필터링
    df = pd.DataFrame(all_data, columns=["_________", "_________"])  # 카테고리 및 항목 열 이름
    df.to_csv("_________", index=False)  # 파일 저장
    print("1. 데이터가 CSV 파일로 저장되었습니다.")

# 6. CSV 파일을 DataFrame으로 불러오기
def load_data_from_csv():
    df = pd.read_csv("_________")  # 저장한 CSV 파일 읽기
    print("\n2. 불러온 DataFrame:")
    print(df.head())
    return df

# 7. 각 카테고리별 데이터 개수 계산 및 분석
def analyze_data(df):
    counts = df["_________"].value_counts()  # 카테고리별 데이터 개수 계산
    print("\n3. 각 카테고리별 데이터 개수:")
    print(counts)

    # 8. 가장 많은/적은 데이터가 있는 카테고리 찾기
    max_category = counts.idxmax()
    min_category = counts.idxmin()
    print(f"\n4. 가장 많은 데이터가 있는 카테고리: {max_category} ({counts[max_category]}개)")
    print(f"   가장 적은 데이터가 있는 카테고리: {min_category} ({counts[min_category]}개)")

    # 9. 가장 긴/짧은 항목 이름 찾기
    df["Item"] = df["Item"].str.replace("\n", " ")  # 줄바꿈 제거
    longest_name = max(df["_________"], key=len)  # 가장 긴 항목
    shortest_name = min(df["_________"], key=len)  # 가장 짧은 항목
    print(f"\n5. 가장 긴 이름: {longest_name} ({len(longest_name)}글자)")
    print(f"   가장 짧은 이름: {shortest_name} ({len(shortest_name)}글자)")

# 메인 함수
def main():
    driver = setup_driver()
    navigate_to_page(driver)
    search_keyword(driver, "_________")  # 검색할 구 이름 입력
    data = scrape_results(driver)
    driver.quit()

    save_data_to_csv(data)
    df = load_data_from_csv()
    analyze_data(df)

if __name__ == "__main__":
    main()
