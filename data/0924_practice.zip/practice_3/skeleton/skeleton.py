import requests
from bs4 import BeautifulSoup
import pandas as pd
import matplotlib.pyplot as plt
import urllib3

# SSL 경고 비활성화
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 한글 폰트 설정 (Mac에서는 AppleGothic, Windows에서는 Malgun Gothic 사용)
plt.rcParams['font.family'] = 'AppleGothic'  # Mac
# plt.rcParams['font.family'] = 'Malgun Gothic'  # Windows
plt.rcParams['axes.unicode_minus'] = False  # 한글 폰트 설정 시 음수 기호 깨짐 방지

# 1. 웹페이지에서 데이터 가져오기
url = "_________"
response = requests.get(url, verify=False)
print("문제 1. 웹페이지 가져오기")
print("답: 상태 코드:", response.status_code)

# 2. BeautifulSoup을 사용하여 HTML 파싱
soup = BeautifulSoup(response.text, 'html.parser')
tables = soup.find_all('_________')

# 첫 번째 테이블 데이터 추출
if tables:
    first_table = tables[_________]
    data = [[td.text.strip() for td in tr.find_all(['_________', '_________'])] for tr in first_table.find_all('tr')]

    # 각 행의 열(column) 수를 맞추기 위해 최대 열 길이를 구하고 빈 칸을 채움
    max_cols = max(len(row) for row in data)
    data = [row + [''] * (max_cols - len(row)) for row in data]  # 열의 개수를 최대 열 길이에 맞춤

    # DataFrame으로 변환
    df = pd.DataFrame(data[_________:], columns=data[_________])  # 첫 번째 행은 컬럼명으로 사용
    print("\n문제 2. 테이블 데이터 추출 및 DataFrame 생성")
    print("DataFrame 요약 정보:")
    print(df.head())

    # 불필요한 빈 열 삭제
    df = df.loc[:, df.columns != '']  # 빈 열 이름을 가진 열 제거

    # 컬럼 이름 확인
    print("\nDataFrame 컬럼명:")
    print(df.columns)

    # '역 수' 데이터를 시각화
    if '_________' in df['구 분'].values:
        station_data = df[df['구 분'] == '_________']
        station_data = station_data.iloc[0, 2:]  # '구 분'과 '계' 열을 제외한 노선별 역 수 데이터

        # 데이터를 숫자로 변환
        station_data = pd.to_numeric(station_data, errors='_________')

        # 노선별 역 수 시각화
        plt.figure(figsize=(10, 6))
        plt.bar(station_data.index, station_data.values)
        plt.title('_________')
        plt.xlabel('_________')
        plt.ylabel('_________')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.show()
    else:
        print("Error: '역 수' 데이터가 존재하지 않습니다.")
else:
    print("답: 테이블이 존재하지 않습니다.")
