import requests
import pandas as pd

# 데이터 수집
api_key = '51766d5a4e646f6835366971667548'
date = '20230901'  # 원하는 날짜로 변경하세요
url = f'http://openapi.seoul.go.kr:8088/{api_key}/json/CardSubwayStatsNew/1/1000/{date}'

response = requests.get(url)
data = response.json()

if 'CardSubwayStatsNew' in data:
    df = pd.DataFrame(data['CardSubwayStatsNew']['row'])
    print("데이터 수집 완료")
else:
    print("데이터를 불러오는데 실패했습니다.")
    print(data)
    exit()

# 중복 및 이상치 제거
# 'GTON_TNOPE' 는 '승차총승객수', ‘GTOFF_TNOPE’는 '하차총승객수'
df = df.drop_duplicates()
df = df[(df['GTON_TNOPE'] < 1000000) & (df['GTOFF_TNOPE'] < 1000000)] # 이상치 제거
print("중복 및 이상치 제거 완료")
