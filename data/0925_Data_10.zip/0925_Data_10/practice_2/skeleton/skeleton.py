import requests
import pandas as pd

# 데이터 수집
api_key = '_________'
date = '_________'
url = f'http://openapi.seoul.go.kr:8088/{api_key}/json/CardSubwayStatsNew/1/1000/{date}'

response = requests.get(url)
data = response._____

if 'CardSubwayStatsNew' in data:
    df = pd.DataFrame(data['CardSubwayStatsNew']['row'])
    print("데이터 수집 완료")
else:
    print("데이터를 불러오는데 실패했습니다.")
    print(data)
    exit()

# 중복 및 이상치 제거
# 'GTON_TNOPE' 는 '승차총승객수', ‘GTOFF_TNOPE’는 '하차총승객수'
df = df._________()  # 중복 제거
df = df[(df['GTON_TNOPE'] < _________) & (df['GTOFF_TNOPE'] < _________)] # 이상치 제거
print("중복 및 이상치 제거 완료")
