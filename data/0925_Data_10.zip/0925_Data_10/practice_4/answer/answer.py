import requests
import pandas as pd

# 데이터 수집
api_key = '51766d5a4e646f6835366971667548'
date = '20230901' # 데이터 수집 날짜
url = f'http://openapi.seoul.go.kr:8088/{api_key}/json/CardSubwayStatsNew/1/1000/{date}'

response = requests.get(url)
data = response.json()

if 'CardSubwayStatsNew' in data:
    df = pd.DataFrame(data['CardSubwayStatsNew']['row'])
    print("데이터 수집 완료")
else:
    print("데이터를 불러오는데 실패했습니다.")
    print(data)
    exit()

# 컬럼명을 한글로 변경
df.rename(columns={
    'SBWY_ROUT_LN_NM': '호선명',
    'SBWY_STNS_NM': '지하철역'
}, inplace=True)

# 새로운 피처 생성
df['호선_역명'] = df['호선명'] + '_' + df['지하철역']
print("새로운 피처 '호선_역명' 생성 완료")

# 새로운 피처 확인
print(df.head())