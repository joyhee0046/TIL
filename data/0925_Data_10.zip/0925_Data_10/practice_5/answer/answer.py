import requests
import pandas as pd
import matplotlib.pyplot as plt

# 데이터 수집
api_key = '51766d5a4e646f6835366971667548'
date = '20230901'
url = f'http://openapi.seoul.go.kr:8088/{api_key}/json/CardSubwayStatsNew/1/1000/{date}'

response = requests.get(url)
data = response.json()

# 데이터프레임으로 변환
df = pd.DataFrame(data['CardSubwayStatsNew']['row'])

# 총승하차인원 계산 및 상위 10개 역 추출
df['Total_Passengers'] = df['GTON_TNOPE'] + df['GTOFF_TNOPE']
top10 = df.sort_values(by='Total_Passengers', ascending=False).head(10)

# 상위 10개 역 영어 변환
station_mapping = {
    '강남': 'Gangnam',
    '잠실(송파구청)': 'Jamsil (Songpa-gu Office)',
    '홍대입구': 'Hongdae',
    '구로디지털단지': 'Guro Digital Complex',
    '삼성(무역센터)': 'Samsung (COEX)',
    '역삼': 'Yeoksam',
    '선릉': 'Seolleung',
    '서울역': 'Seoul Station',
    '신림': 'Sillim',
    '을지로입구': 'Euljiro Entrance'
}
top10['Subway_Station'] = top10['SBWY_STNS_NM'].replace(station_mapping)

# 상위 10개 역을 막대그래프를 이용하여 시각화
plt.bar(top10['Subway_Station'], top10['Total_Passengers'])
plt.xlabel('Subway Station')
plt.ylabel('Total Passengers')
plt.title('Total Passengers at Top 10 Stations')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
