import numpy as np

# 평균이 0이고 표준편차가 1인 정규분포 데이터를 1000개 생성
data = np.random.normal(0, 1, 1000)

# 평균과 표준편차 계산
mean = np.mean(data)
std_dev = np.std(data)

# 결과 출력
print(f"Calculated Mean: {mean:.2f}")
print(f"Calculated Standard Deviation: {std_dev:.2f}")
