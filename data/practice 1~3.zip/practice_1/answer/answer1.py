import numpy as np

# 평균이 0이고 표준편차가 1인 정규분포 데이터를 1000개 생성
data = np.random.normal(0, 1, 1000)

# 생성된 데이터 출력 (처음 10개만)
print(data[:10])
