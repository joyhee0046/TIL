import pandas as pd

# 데이터 로드
file_path = ____________
data = ___________

# 데이터 확인
print(data.head())
