import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 데이터 로드
file_path = '../data/sample_data.csv'
data = pd.read_csv(file_path)

# 특정 조건을 만족하는 데이터 필터링 (예: 특정 열 값이 10에서 20 사이)
filtered_data = data.loc[(data['column_name'] >= 10) & (data['column_name'] <= 20)]

# 다른 변수와의 관계 시각화 (예: column_name과 다른 변수 간의 관계)
plt.figure(figsize=(10, 6))
sns.scatterplot(x='column_name', y='other_column_name', data=filtered_data)
plt.title('Scatter Plot of Filtered Data')
plt.xlabel('column_name')
plt.ylabel('other_column_name')
plt.show()
