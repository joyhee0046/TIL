import pandas as pd

# 데이터 로드
file_path = ___________
data = ___________

# 특정 조건을 만족하는 데이터 필터링 (예: 특정 열 값이 10에서 20 사이)
filtered_data = data.loc[(_____________) & (______________)]

# 필터링된 데이터 확인
print(filtered_data.head())
