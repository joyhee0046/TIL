import pandas as pd

# 데이터 로드
file_path = _____________
data = _____________

# 데이터 확인
print(data.head())
