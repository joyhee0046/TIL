import pandas as pd

# 데이터 로드
file_path = _____________
data = ____________

# 기본적인 기술 통계 계산
statistics = ____________

# 기술 통계 확인
print(statistics)
