import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 데이터 로드
file_path = '../data/statistics_data.csv'
data = pd.read_csv(file_path)

# 열 이름 확인
print(data.columns)  # DataFrame의 열 이름을 출력하여 확인

# 히스토그램과 KDE 플롯 시각화
if 'column_1' in data.columns:  # 'column_1' 열이 있는지 확인
    plt.figure(figsize=(12, 6))
    sns.histplot(data['column_1'], kde=True)
    plt.title('Histogram and KDE of column_1')
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.show()
else:
    print("Column 'column_1' does not exist in DataFrame.")
