import streamlit as st
import pandas as pd


# 판다스를 이용하여 excel 파일에서 '2024년 07월'과 '수집지점 주소 및 좌표'시트의 데이터룰 불러오기
# 각각 traffic_data 와 location_data 변수로 불러오기
traffic_data = pd.read_excel('../data/traffic_2024_07.xlsx', sheet_name='2024년 07월')
location_data = pd.read_excel('../data/traffic_2024_07.xlsx', sheet_name='수집지점 주소 및 좌표')

# streamlit의 title함수를 이용하여 제목('서울시 교통량 인터랙티브 시각화') 출력
st.title('서울시 교통량 인터랙티브 시각화')

# streamlit의 selectbox() 위젯을 사용하여 사용자로부터 traffic_data에 존재하는 '일자' 중 하나를 선택할 수 있도록 함
# 참고: https://docs.streamlit.io/develop/api-reference/widgets/st.selectbox
dates = sorted(traffic_data['일자'].unique())
selected_date = st.selectbox('일자를 선택하세요', dates)

# streamlit의 multiselect() 위젯을 사용하여 사용자로부터 location_data에 존재하는 '지점명' 중 하나 이상을 선택할 수 있도록 함
# 참고: https://docs.streamlit.io/develop/api-reference/widgets/st.multiselect
locations = traffic_data['지점명'].unique()
selected_locations = st.multiselect('지점명을 선택하세요', locations, default=locations[0])

# 선택한 날짜와 지점명을 보여주기 위해 해당 내용을 필터링
filtered_data = traffic_data[(traffic_data['일자'] == selected_date) & (traffic_data['지점명'].isin(selected_locations))]

# 현재 traffic_data의 시간대를 나타내는 column 명들이 '0시', '1시', '2시'등으로 표현되어있기 때문에 이를 고려하여 교통량 컬럼 선택
time_columns = [str(i) + '시' for i in range(24)]

# 필터링된 데이터의 시간대별 교통량 합계 계산
if not filtered_data.empty:
    traffic_sum = filtered_data[time_columns].sum()
    st.write('## 선택한 지점들의 시간대별 교통량 합계')
    # 교통량을 시계열 그래프인 line_chart로 표시
    # 참고 line_chart: https://docs.streamlit.io/develop/api-reference/charts/st.line_chart
    st.line_chart(traffic_sum)
else:
    st.write('선택한 조건에 해당하는 데이터가 없습니다.')
