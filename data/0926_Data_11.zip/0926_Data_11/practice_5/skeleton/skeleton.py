import streamlit as st
import pandas as pd


# 판다스를 이용하여 excel 파일에서 '2024년 07월'과 '수집지점 주소 및 좌표'시트의 데이터룰 불러오기
# 각각 traffic_data 와 location_data 변수로 불러오기


# streamlit의 title함수를 이용하여 제목('서울시 교통량 인터랙티브 시각화') 출력


# streamlit의 selectbox() 위젯을 사용하여 사용자로부터 traffic_data에 존재하는 '일자' 중 하나를 선택할 수 있도록 함
# 참고: https://docs.streamlit.io/develop/api-reference/widgets/st.selectbox


# streamlit의 multiselect() 위젯을 사용하여 사용자로부터 location_data에 존재하는 '지점명' 중 하나 이상을 선택할 수 있도록 함
# 참고: https://docs.streamlit.io/develop/api-reference/widgets/st.multiselect


# 선택한 날짜와 지점명을 보여주기 위해 해당 내용을 필터링



# 교통량을 시계열 그래프인 line_chart로 표시
# 필터링된 데이터의 시간대별 교통량 합계 계산
# 현재 traffic_data의 시간대를 나타내는 column 명들이 '0시', '1시', '2시'등으로 표현되어있기 때문에 이를 고려하여 교통량 컬럼 선택
# 참고 line_chart: https://docs.streamlit.io/develop/api-reference/charts/st.line_chart
