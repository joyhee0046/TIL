import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# 판다스를 이용하여 excel 파일에서 '2024년 07월' 시트의 데이터 불러오기
data = pd.read_excel('../data/traffic_2024_07.xlsx', sheet_name='2024년 07월')

# streamlit의 title함수를 이용하여 제목('서울시 2024년 7월 교통 데이터 시각화 앱') 출력
st.title('서울시 2024년 7월 교통 데이터 분석 앱')

# 시간대별 교통량 컬럼들을 0시 부터 23시중 하나의 시간대를 st의 selectbox() 위젯을 사용하여 선택하도록 함
time_columns = [str(i) + '시' for i in range(24)]
selected_column = st.selectbox('분석할 시간대를 선택하세요', time_columns)

# 선택한 열의 히스토그램 그리기
st.write(f'## {selected_column} 교통량 히스토그램')
fig, ax = plt.subplots()
ax.hist(data[selected_column].dropna(), bins=20)
# matplotlib의 histogram을 streamlit의 pyplot함수를 이용해서 웹 화면에 표시
# 참고: https://docs.streamlit.io/develop/api-reference/charts/st.pyplot
st.pyplot(fig)


st.write(f'## {selected_column} 교통량 통계 정보')
# st.write를 사용하여 dataframe의 describe함수의 출력 결과를 선택한 열의 통계 정보를 웹 화면에 표시
st.write(data[selected_column].describe())
