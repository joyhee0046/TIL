import streamlit as st
import pandas as pd

# 판다스를 이용하여 excel 파일에서 '수집지점 주소 및 좌표' 시트의 데이터 불러오기
data = pd.read_excel('../data/traffic_2024_07.xlsx', sheet_name='수집지점 주소 및 좌표')

# streamlit의 title함수를 이용하여 제목('서울시 교통 지점 위치 지도 시각화') 출력
st.title('서울시 교통 지점 위치 지도 시각화')

# 지도에 표시할 데이터중 위도와 경도가 있는 데이터만 추출 (결측치 제거)
# map_data = data[['latitude', 'longitude']].dropna()
map_data = data[['위도', '경도']].dropna()


st.write('## 교통 지점 위치')
# 지도에 데이터를 streamlit의 map() 함수를 사용하여 표시
# 참고: https://docs.streamlit.io/develop/api-reference/charts/st.map
#  streamlit의 map() 에서 추가적인 latitude와 longitude 컬럼명을 명시하지 않는다면
# 'LAT', 'LATITUDE', 'lat', 'latitude' 컬럼이 존재하는지 확인하고 존재한다면 위도로 사용
# 'LON', 'LONGITUDE', 'lon', 'longitude' 컬럼이 존재하는지 확인하고 존재한다면 경도로 사용
# 만약 존재하지 않는다면 에러를 발생시킵니다.
# 우리의 위도와 경도 컬럼명은 '위도'와 '경도'이므로 컬럼명을 파라미터로 전달하여 지도에 표시
st.map(map_data, latitude='위도', longitude='경도')
