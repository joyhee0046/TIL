import streamlit as st
import pandas as pd

# 판다스를 이용하여 excel 파일에서 '2024년 07월' 시트의 데이터 불러오기
data = pd.read_excel('../data/traffic_2024_07.xlsx', sheet_name='2024년 07월')

# Streamlit의 title을 사용하여 웹 애플리케이션의 제목을 '서울시 2024년 7월 교통 데이터 대화형 시각화'로 출력합니다
st.title('서울시 2024년 7월 교통 데이터 대화형 시각화')

# Streamlit의 st.slider() 위젯을 사용하여 사용자로부터 표시할 데이터의 행 수를 입력받습니다.
# (최소값: 1, 최대값: 100, 기본값: 5)
# 참고: https://docs.streamlit.io/develop/api-reference/widgets/st.slider
row_count = st.slider('표시할 행 수를 선택하세요', min_value=1, max_value=100, value=5)

# 선택한 행 수만큼 데이터 표시
st.write(f'## 상위 {row_count}개 데이터')
# Streamlit의 st.dataframe() 함수를 사용하여 데이터프레임의 상위 행 row_count개의 행을 출력합니다.
st.dataframe(data.head(row_count))
