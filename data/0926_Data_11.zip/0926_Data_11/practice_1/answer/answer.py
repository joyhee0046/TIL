import streamlit as st
import pandas as pd

# 판다스를 이용하여 excel 파일에서 '2024년 07월' 시트의 데이터 불러오기
data = pd.read_excel('../data/traffic_2024_07.xlsx', sheet_name='2024년 07월')

# streamlit의 title함수를 이용하여 제목('서울시 2024년 7월 교통 데이터 시각화 앱') 출력
st.title('서울시 2024년 7월 교통 데이터 시각화 앱')

st.write('## 데이터 미리보기')
# streamlit의 dataframe을 이용하여 데이터프레임 표시
st.dataframe(data.head())

