import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import folium

# 1. 웹 드라이버 설정
def setup_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("_________")  # --no-sandbox
    options.add_argument("_________")  # --disable-dev-shm-usage
    driver = webdriver.Chrome(options=options)
    return driver

# 2. 웹페이지로 이동
def navigate_to_page(driver):
    try:
        driver.get("_________")  # 서울시 실시간 교통 정보 웹페이지 URL
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, "_________")))  # 페이지가 완전히 로드될 때까지 대기
        print("페이지에 접속했습니다.")
    except TimeoutException:
        print("페이지 로드 시간이 초과되었습니다.")
        driver.quit()

# 3. 검색 기능 사용 및 데이터 수집
def search_keyword(driver, keyword):
    try:
        print(f"'{keyword}' 정류소 정보를 수집합니다.")
        contents_area = driver.find_element(By.ID, "_________")  # 검색 영역을 찾기 위한 ID
        search_box = contents_area.find_element(By.CSS_SELECTOR, "input._________")  # 검색창 CSS Selector
        search_box.clear()
        search_box.send_keys(keyword)
        search_button = contents_area.find_element(By.CSS_SELECTOR, "input._________")  # 검색 버튼 CSS Selector
        search_button.click()
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.CLASS_NAME, "_________")))  # 결과 대기
        print(f"'{keyword}' 검색 결과를 찾았습니다.")
    except TimeoutException:
        print("검색 결과 로드 시간이 초과되었습니다.")
        driver.quit()

# 4. 정류소 데이터 추출
def scrape_bus_stop_data(driver):
    print("정류소 정보를 수집합니다.")
    try:
        aside_content = driver.find_element(By.CLASS_NAME, "_________")  # 검색 결과 영역 찾기
        results = aside_content.find_element(By.ID, "_________").find_elements(By.TAG_NAME, "_________")  # 정류소 리스트 항목 추출
        data = []
        for result in results:
            try:
                name = result.find_element(By.TAG_NAME, "_________").text.strip()
                bus_stop_number = name.split("(")[-1].replace(")", "")  # 정류소 번호 추출
                data.append([name, bus_stop_number])
            except NoSuchElementException:
                print("일부 정류소 정보를 찾을 수 없습니다.")
        df = pd.DataFrame(data, columns=['정류소 이름', '정류소 번호'])
        print("정류소 정보가 성공적으로 수집되었습니다.")
        return df
    except NoSuchElementException:
        print("정류소 정보를 찾을 수 없습니다.")
        return pd.DataFrame()
    except TimeoutException:
        print("정류소 정보 수집 중 시간이 초과되었습니다.")
        return pd.DataFrame()
    except Exception as e:
        print(f"정류소 정보 수집 중 오류 발생: {e}")
        return pd.DataFrame()

# 5. 지도 시각화
def visualize_data(df):
    if df.empty:
        print("시각화할 데이터가 없습니다.")
        return

    # 임의의 좌표를 사용하여 지도 생성
    map_center = [_________, _________]  # 강남구 중심 좌표 또는 임의의 좌표
    m = folium.Map(location=map_center, zoom_start=_________)  # 기본 줌 설정

    # 정류소를 지도에 마커로 표시
    for index, row in df.iterrows():
        folium.Marker(
            location=[_________, _________],  # 좌표 설정
            popup=row['_________'],  # 마커에 표시할 정보
            tooltip=row['_________']  # 마커에 표시할 도구 설명
        ).add_to(m)

    # 지도 저장
    m.save("_________")  # 저장할 파일명
    print("정류소 시각화가 완료되었습니다. 파일을 확인하세요.")

# 메인 함수
def main():
    driver = setup_driver()

    # 페이지로 이동
    navigate_to_page(driver)

    # 정류소 검색 및 데이터 수집
    search_keyword(driver, "_________")  # 검색할 구 이름

    # 정류소 데이터 추출
    df = scrape_bus_stop_data(driver)

    # 브라우저 종료
    driver.quit()

    # 데이터 확인 및 시각화
    if not df.empty:
        print("\n수집된 정류소 데이터 분석:")
        print(df.head())
        print(f"총 {len(df)}개의 정류소가 수집되었습니다.")

        # 중복된 정류소 확인
        if df.duplicated(subset=['정류소 번호']).any():
            print("중복된 정류소가 있습니다.")
        else:
            print("중복된 정류소가 없습니다.")

        # 지도 시각화
        visualize_data(df)
    else:
        print("정류소 데이터 수집에 실패하였습니다.")


if __name__ == "__main__":
    main()
