import sys
sys.stdin = open("input.txt", 'r')

