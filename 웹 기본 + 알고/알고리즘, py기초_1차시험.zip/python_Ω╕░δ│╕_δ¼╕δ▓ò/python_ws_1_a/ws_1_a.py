# 아래에 코드를 작성하시오.
name = "Alice"
age = 25
hight = 5.6
is_student =True

print(name)
print(age)
print(hight)
print(is_student)
print(f"{name}는 {age}살이고, 키는 {hight}이며 학생 여부는 {is_student}입니다.")