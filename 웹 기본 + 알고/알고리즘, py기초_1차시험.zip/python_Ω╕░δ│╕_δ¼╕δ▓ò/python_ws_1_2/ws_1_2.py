# 아래에 코드를 작성하시오.

friends = ["Alice","Bob","Charlie"]
user_info={'username': 'user123','age' :20, 'is_active' : True}
print(friends)
print(user_info)
friends.append("David")
print(friends)
user_info["email"] = 'user123@example.com'
print(user_info)