# 아래에 코드를 작성하시오.

username = 'user123'
print(username)
age = 20
print(age)
is_active = True
print(is_active)

print(f"Username: {username}, Age: {age}, Active: {is_active}")
age +=5
print(age)