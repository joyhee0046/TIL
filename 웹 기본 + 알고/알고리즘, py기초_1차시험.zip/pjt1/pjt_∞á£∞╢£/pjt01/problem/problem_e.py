# TMDB API 키 설정
API_KEY = 'YOUR_API_KEY'
BASE_URL = ''

# movie 정보를 로드하는 함수 (problem_a.py의 결과 활용)

# 리뷰 정보를 로드하는 함수 (problem_c.py의 결과 활용)

# API를 사용하여 영화 평점 정보 가져오기

# 영화 평점 데이터 처리 함수

# 데이터 수집 및 CSV 파일로 저장
