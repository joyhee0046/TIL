# ctrl + s 
print('hello')