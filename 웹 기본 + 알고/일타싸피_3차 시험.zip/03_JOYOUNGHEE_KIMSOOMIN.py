import socket
import time
import math

# 닉네임을 사용자에 맞게 변경해 주세요.
NICKNAME = '3_조영희_김수민'
# 팀ID : PT00014462
# 팀key : XHXA-YXQH-RNTH-KPJF


# 일타싸피 프로그램을 로컬에서 실행할 경우 변경하지 않습니다.
HOST = '127.0.0.1'

# 일타싸피 프로그램과 통신할 때 사용하는 코드값으로 변경하지 않습니다.
PORT = 1447
CODE_SEND = 9901
CODE_REQUEST = 9902
SIGNAL_ORDER = 9908
SIGNAL_CLOSE = 9909


# 게임 환경에 대한 상수입니다.
TABLE_WIDTH = 254
TABLE_HEIGHT = 127
NUMBER_OF_BALLS = 6
HOLES = [[0, 0], [127, 0], [254, 0], [0, 127], [127, 127], [254, 127]]

order = 0
balls = [[0, 0] for i in range(NUMBER_OF_BALLS)]

sock = socket.socket()
print('Trying to Connect: %s:%d' % (HOST, PORT))
sock.connect((HOST, PORT))
print('Connected: %s:%d' % (HOST, PORT))

send_data = '%d/%s' % (CODE_SEND, NICKNAME)
sock.send(send_data.encode('utf-8'))
print('Ready to play!\n--------------------')

def is_ball_in_path(white_x, white_y, target_x, target_y, ball_x, ball_y):
    # Check if a ball is in the direct path between the white ball and the target ball
    def on_line(p1, p2, p):
        return abs((p2[1] - p1[1]) * (p[0] - p1[0]) - (p2[0] - p1[0]) * (p[1] - p1[1])) < 1e-6

    def distance(p1, p2):
        return math.sqrt((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2)

    ball_distance = distance([white_x, white_y], [ball_x, ball_y])
    white_target_distance = distance([white_x, white_y], [target_x, target_y])
    ball_target_distance = distance([ball_x, ball_y], [target_x, target_y])

    return (ball_distance < white_target_distance and
            ball_target_distance < white_target_distance and
            on_line([white_x, white_y], [target_x, target_y], [ball_x, ball_y]))

while True:

    # Receive Data
    recv_data = (sock.recv(1024)).decode()
    print('Data Received: %s' % recv_data)

    # Read Game Data
    split_data = recv_data.split('/')
    idx = 0
    try:
        for i in range(NUMBER_OF_BALLS):
            for j in range(2):
                balls[i][j] = float(split_data[idx])
                idx += 1
    except:
        send_data = '%d/%s' % (CODE_REQUEST, NICKNAME)
        print("Received Data has been currupted, Resend Requested.")
        continue

    # Check Signal for Player Order or Close Connection
    if balls[0][0] == SIGNAL_ORDER:
        order = int(balls[0][1])
        print('\n* You will be the %s player. *\n' % ('first' if order == 1 else 'second'))
        # 목적구 설정을 위한 타겟
        if order == 1:
            target = 1
        else :
            target = 2
        continue
    elif balls[0][0] == SIGNAL_CLOSE:
        break

    # Show Balls' Position
    print('====== Arrays ======')
    for i in range(NUMBER_OF_BALLS):
        print('Ball %d: %f, %f' % (i, balls[i][0], balls[i][1]))
    print('====================')

    angle = 0.0
    power = 0.0

    
    
    ##############################
    # 이 위는 일타싸피와 통신하여 데이터를 주고 받기 위해 작성된 부분이므로 수정하면 안됩니다.
    #
    # 모든 수신값은 변수, 배열에서 확인할 수 있습니다.
    #   - order: 1인 경우 선공, 2인 경우 후공을 의미
    #   - balls[][]: 일타싸피 정보를 수신해서 각 공의 좌표를 배열로 저장
    #     예) balls[0][0]: 흰 공의 X좌표
    #         balls[0][1]: 흰 공의 Y좌표
    #         balls[1][0]: 1번 공의 X좌표
    #         balls[4][0]: 4번 공의 X좌표
    #         balls[5][0]: 마지막 번호(8번) 공의 X좌표

    # 여기서부터 코드를 작성하세요.
    # 아래에 있는 것은 샘플로 작성된 코드이므로 자유롭게 변경할 수 있습니다.

    print(balls)

    print(target)

    # whiteBall_x, whiteBall_y: 흰 공의 X, Y좌표를 나타내기 위해 사용한 변수
    whiteBall_x = balls[0][0]
    whiteBall_y = balls[0][1]
    # targetBall_x, targetBall_y: 목적구의 X, Y좌표를 나타내기 위해 사용한 변수
    targetBall_x = balls[target][0]
    targetBall_y = balls[target][1]

    # # width, height: 목적구와 흰 공의 X좌표 간의 거리, Y좌표 간의 거리
    # width = abs(targetBall_x - whiteBall_x)
    # height = abs(targetBall_y - whiteBall_y)
    
    # 8번공을 마지막에 치기 위해서 확인
    ball_clear = 0
    # 이번 타구에 성공했다면
    if targetBall_x == -1.0 :
        # 1번 3번공을 확인하기 위한 반복문
        for which in range(order,5,2) :
            # 목적구가 될 수 있는 공이라면
            if balls[which][0] != -1.0 :
                # 목적구로 설정
                target = which
                targetBall_x = balls[target][0]
                targetBall_y = balls[target][1]
                break
            else :
                # 이미 클리어한 공이라면 +1
                ball_clear += 1
    # 타구에 두 번 성공했다면, 더이상 나의 목적구가 없으므로 8번공을 목적구로 설정
    if ball_clear == 2 :
        target = 5
        targetBall_x = balls[target][0]
        targetBall_y = balls[target][1]

    width = abs(targetBall_x - whiteBall_x)
    height = abs(targetBall_y - whiteBall_y)
    
    # Check if the path is blocked by another ball
    blocked = False
    for i in range(1, NUMBER_OF_BALLS):
        if i != target and balls[i][0] != -1.0:
            if is_ball_in_path(whiteBall_x, whiteBall_y, targetBall_x, targetBall_y, balls[i][0], balls[i][1]):
                blocked = True
                break

    if blocked:
        print('Path to target is blocked, selecting an alternative target.')
        for i in range(order, NUMBER_OF_BALLS, 2):
            if balls[i][0] != -1.0 and i != target:
                target = i
                break
        whiteBall_x = balls[0][0]
        whiteBall_y = balls[0][1]
        # targetBall_x, targetBall_y: 목적구의 X, Y좌표를 나타내기 위해 사용한 변수
        targetBall_x = balls[target][0]
        targetBall_y = balls[target][1]
        # width, height: 목적구와 흰 공의 X좌표 간의 거리, Y좌표 간의 거리
        width = abs(targetBall_x - whiteBall_x)
        height = abs(targetBall_y - whiteBall_y)
    

    # radian: width와 height를 두 변으로 하는 직각삼각형의 각도를 구한 결과
    #   - 1radian = 180 / PI (도)
    #   - 1도 = PI / 180 (radian)
    # angle: 아크탄젠트로 얻은 각도 radian을 degree로 환산한 결과
    radian = math.atan(width / height) if height > 0 else 0
    angle = 180 / math.pi * radian
    #print('**********0**********')
    
    # 목적구가 흰 공과 상하좌우로 일직선상에 위치했을 때 각도 입력
    if whiteBall_x == targetBall_x:
        if whiteBall_y < targetBall_y:
            angle = 0
            #print('**********1**********')
        else:
            angle = 180
            #print('**********2**********')

    elif whiteBall_y == targetBall_y:
        if whiteBall_x < targetBall_x:
            angle = 90
            #print('**********3**********')
        else:
            angle = 270
            #print('**********4**********')

    # 목적구가 1사분면에 위치했다면 기본 계산 각으로 실행
    # 목적구가 흰 공을 중심으로 3사분면에 위치했을 때 각도를 재계산
    #print(whiteBall_x, targetBall_x, whiteBall_y, targetBall_y)
    if whiteBall_x > targetBall_x and whiteBall_y > targetBall_y:
        radian = math.atan(width / height)
        angle = (180 / math.pi * radian) + 180
        #print('**********5**********')

    # 목적구가 흰 공을 중심으로 2사분면에 위치했을 때 각도를 재계산
    elif whiteBall_x > targetBall_x and whiteBall_y < targetBall_y:
        radian = math.atan(height / width)
        angle = (180 / math.pi * radian) - 90
        #print('**********7**********')
    
    # 목적구가 흰 공을 중심으로 4사분면에 위치했을 때 각도를 재계산
    elif whiteBall_x < targetBall_x and whiteBall_y > targetBall_y:
        radian = math.atan(height / width)
        angle = (180 / math.pi * radian) + 90
        #print('**********6**********')
    
    # distance: 두 점(좌표) 사이의 거리를 계산
    distance = math.sqrt(width**2 + height**2)
    
    # power: 거리 distance에 따른 힘의 세기를 계산
    power = distance * 0.7
    print(distance)

    if distance > 100 :
        power = distance * 0.65
    if distance > 130 :
        power = distance * 0.6
    if distance > 150 : 
        power = distance * 0.55

    # 거리가 너무 가까워서 동작이 무의미하다면 최대 파워로 거리 조절
    if distance < 10 :
        power = 99

    # 주어진 데이터(공의 좌표)를 활용하여 두 개의 값을 최종 결정하고 나면,
    # 나머지 코드에서 일타싸피로 값을 보내 자동으로 플레이를 진행하게 합니다.
    #   - angle: 흰 공을 때려서 보낼 방향(각도)
    #   - power: 흰 공을 때릴 힘의 세기
    # 
    # 이 때 주의할 점은 power는 100을 초과할 수 없으며,
    # power = 0인 경우 힘이 제로(0)이므로 아무런 반응이 나타나지 않습니다.
    #
    # 아래는 일타싸피와 통신하는 나머지 부분이므로 수정하면 안됩니다.
    ##############################

    merged_data = '%f/%f/' % (angle, power)
    sock.send(merged_data.encode('utf-8'))
    print('Data Sent: %s' % merged_data)

    # 8번공을 마지막에 치기 위해서 확인
    # 이번 타구에 성공했다면
    if targetBall_x == -1.0 :
        # 1번 3번공을 확인하기 위한 반복문
        for which in range(order,5,2) :
            # 목적구가 될 수 있는 공이라면
            if balls[which][0] != -1.0 :
                # 목적구로 설정
                target = which
                break
            else :
                # 이미 클리어한 공이라면 +1
                ball_clear += 1
    # 타구에 두 번 성공했다면, 더이상 나의 목적구가 없으므로 8번공을 목적구로 설정
    if ball_clear == 2 :
        target = 5

    # 목적구가 8번공이라면, 이번 라운드를 모두 끝낸것이 맞는지 다시 확인
    if target == 5 :
        for which in range(order,5,2) :
            if balls[which][0] != -1.0 :
                target = which
                break

sock.close()
print('Connection Closed.\n--------------------')